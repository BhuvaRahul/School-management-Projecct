package com.example.global_knowledge_school

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
