import 'package:flutter/material.dart';
import 'package:global_knowledge_school/utils/colors.dart';

commonAppbar({
  required Widget? lable,
  Color? backgroundColor,
  Widget? leadings,
}) =>
    AppBar(
      title: lable,
      backgroundColor: green300,
    );
