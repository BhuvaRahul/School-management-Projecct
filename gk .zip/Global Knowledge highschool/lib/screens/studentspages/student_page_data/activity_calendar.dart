import 'package:flutter/material.dart';


class ActivityCalendar extends StatefulWidget {
  const ActivityCalendar({Key? key}) : super(key: key);

  @override
  State<ActivityCalendar> createState() => _ActivityCalendarState();
}

class _ActivityCalendarState extends State<ActivityCalendar> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: const [],
      ),
    );
  }
}
