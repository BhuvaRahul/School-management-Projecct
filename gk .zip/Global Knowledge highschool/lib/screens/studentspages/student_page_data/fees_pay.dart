import 'package:global_knowledge_school/common_package.dart';

class FeesPay extends StatefulWidget {
  const FeesPay({Key? key}) : super(key: key);

  @override
  State<FeesPay> createState() => _FeesPayState();
}

class _FeesPayState extends State<FeesPay> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          'Fees Pay',
          style: headingStyle(),
        )),
        body: Column(
          children: [
            SizedBox(height: Screens.height(context) * 0.011),
            Card(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
              child: Container(
                height: Screens.height(context) * 0.26,
                width: Screens.width(context) * double.infinity,
                decoration: BoxDecoration(
                    color: yellow50, borderRadius: BorderRadius.circular(30)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            Text(
                              '  Total \nAmount',
                              style: commonStyle(),
                            ),
                            Text(
                              'Rs. 14,000',
                              style: commonStyle(),
                            )
                          ],
                        ),
                        Container(
                          height: Screens.height(context) * 0.13,
                          width: Screens.width(context) * 0.009,
                          color: black,
                        ),
                        Column(
                          children: [
                            Text(
                              '   Paid \nAmount',
                              style: commonStyle(fontColor: Colors.purple),
                            ),
                            Text(
                              'Rs. 14,000',
                              style: commonStyle(fontColor: Colors.purple),
                            )
                          ],
                        ),
                        Container(
                          height: Screens.height(context) * 0.13,
                          width: Screens.width(context) * 0.009,
                          color: black,
                        ),
                        Column(
                          children: [
                            Text(
                              'Remaining \n  Amount',
                              style: commonStyle(fontColor: red),
                            ),
                            Text(
                              'Rs. 0.00',
                              style: commonStyle(fontColor: Colors.red),
                            )
                          ],
                        ),
                      ],
                    ),
                    Container(
                      height: Screens.height(context) * 0.006,
                      width: double.infinity,
                      color: black,
                    ),
                    commonButtons(
                        lable: Text('Pay Now', style: commonStyle()),
                        onPress: () {},
                        minWidths: 300)
                  ],
                ),
              ),
            ),
            SizedBox(
              height: Screens.height(context) * 0.06,
            ),
            Card(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              child: Container(
                height: Screens.height(context) * 0.28,
                width: Screens.width(context) * double.infinity,
                color: yellow50,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 100.0),
                      child: Text(
                        'Receipt Details',
                        style: headingStyle(),
                      ),
                    ),
                    const SizedBox(height: 15),
                    Text(
                      '  Name :- Rahul Bhuva',
                      style: commonStyle(),
                    ),
                    Text(
                      '  Roll No. :- 201503100510026',
                      style: commonStyle(),
                    ),
                    Text(
                      '  Receipt No.:-123 ',
                      style: commonStyle(),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 110.0, top: 15),
                      child: commonButtons(
                          lable: Text(
                            'View',
                            style: commonStyle(),
                          ),
                          onPress: () {}),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
