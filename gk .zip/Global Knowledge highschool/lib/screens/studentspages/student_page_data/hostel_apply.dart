import 'package:global_knowledge_school/common_package.dart';

class HostelApply extends StatefulWidget {
  const HostelApply({Key? key}) : super(key: key);

  @override
  State<HostelApply> createState() => _HostelApplyState();
}

class _HostelApplyState extends State<HostelApply> {
  TextEditingController txtNameController = TextEditingController();
  TextEditingController txtMobilenoController = TextEditingController();
  TextEditingController txtEmailController = TextEditingController();
  TextEditingController txtStdController = TextEditingController();
  TextEditingController txtClasssController = TextEditingController();
  TextEditingController txtRollController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
          lable: Text(
            hostelApply,
            style: headingStyle(),
          ),
        ),
        body: SingleChildScrollView(
          physics: const NeverScrollableScrollPhysics(),
          child: Column(
            children: [
              commonTextFormField(
                controller: txtNameController,
                hintTex: studentName,
              ),
              commonTextFormField(
                  controller: txtMobilenoController,
                  hintTex: facultyMobile,
                  keyBordTypes: TextInputType.phone),
              commonTextFormField(
                  controller: txtEmailController,
                  hintTex: facultyEmail,
                  keyBordTypes: TextInputType.emailAddress),
              Row(
                children: [
                  Expanded(
                    child: commonTextFormField(
                        controller: txtStdController,
                        hintTex: studentStd,
                        keyBordTypes: TextInputType.number),
                  ),
                  Expanded(
                    child: commonTextFormField(
                      controller: txtClasssController,
                      hintTex: studentClass,
                    ),
                  ),
                ],
              ),
              commonTextFormField(
                controller: txtRollController,
                hintTex: rollNo,
              ),
              commonButtons(
                lable: const Text(submit),
                onPress: () {
                  hostelApplyDetails.add({
                    'name': txtNameController.text,
                    'mobileNumber': txtMobilenoController.text,
                    'email': txtEmailController.text,
                    'std': txtStdController.text,
                    'class': txtClasssController.text,
                    'rollNo': txtRollController.text,
                  });
                  Navigator.pop(context);
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}

List<Map> hostelApplyDetails = [];
