import 'package:global_knowledge_school/common_package.dart';

class StudentPage extends StatefulWidget {
  const StudentPage({Key? key}) : super(key: key);

  @override
  State<StudentPage> createState() => _StudentPageState();
}

class _StudentPageState extends State<StudentPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: green300,
        leading: commonAppContainer(),
        title: Row(
          children: [
            horizontalSpace(horizontal: Screens.width(context) * 0.05),
            const AutoSizeText(
              student,
              presetFontSizes: [23, 22, 20],
              style: TextStyle(color: black),
            ),
          ],
        ),
      ),
      endDrawer: Drawer(
        child: Column(
          children: [
            const DrawerHeader(
                child: CircleAvatar(
              radius: 60,
              backgroundColor: white,
              backgroundImage: AssetImage('assets/images/school logo.png'),
            )),
            Expanded(
              child: ListView.separated(
                itemCount: drawer.length,
                separatorBuilder: (context, index) =>
                    const Divider(thickness: 1),
                itemBuilder: (context, index) => ListTile(
                  leading: Icon(drawer[index]['ic']),
                  title: Text(drawer[index]['txt'], style: commonStyle()),
                  onTap: () {
                    if (index == 0) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ApplyLeave(),
                          ));
                    }
                    if (index == 1) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HostelApply(),
                          ));
                    }
                    if (index == 3) {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const EnterPage()),
                      );
                    }
                  },
                ),
              ),
            )
          ],
        ),
      ),
      body: SafeArea(
        child: GridView.count(
          crossAxisCount: 2,
          childAspectRatio: 1.31,
          children: List.generate(
              stdPage.length,
              (index) => Column(
                    children: [
                      SizedBox(height: Screens.height(context) * 0.023),
                      GestureDetector(
                        onTap: () {
                          if (index == 0) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ShowHomework(
                                    homeworkIndex: index,
                                    homework: homeworkShow[index]
                                        ['homeworkList'],
                                  ),
                                ));
                          }
                          if (index == 1) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const ApplyLeave()));
                          }
                          if (index == 2) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const StudentTimeTables()));
                          }
                          if (index == 5) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const HostelApply(),
                                ));
                          }
                          if (index == 6) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const FeesPay(),
                                ));
                          }
                          if (index == 7) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const ActivityCalendar(),
                                ));
                          }
                          if (index == 8) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const FacultyDetails(),
                                ));
                          }
                        },
                        child: Card(
                          elevation: 10,
                          shape: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20)),
                          child: Container(
                            height: 90,
                            width: Screens.width(context) * 0.41,
                            decoration: BoxDecoration(
                              color: green300,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Icon(stdPage[index]['ic'], size: 50),
                          ),
                        ),
                      ),
                      Text(stdPage[index]['tlt'], style: commonStyle()),
                    ],
                  )),
        ),
      ),
    );
  }
}

List<Map> stdPage = [
  {'tlt': 'HomeWork', 'ic': Icons.pages_outlined},
  {'tlt': 'Apply Leave', 'ic': Icons.time_to_leave},
  {'tlt': 'Time Table', 'ic': Icons.table_chart_outlined},
  {'tlt': 'Festival Images', 'ic': Icons.image_outlined},
  {'tlt': 'Attendance', 'ic': Icons.tab},
  {'tlt': 'Hostel Apply', 'ic': Icons.home_work_outlined},
  {'tlt': 'Fees', 'ic': Icons.money},
  {'tlt': 'Activity Calender', 'ic': Icons.calendar_today},
  {'tlt': 'Faculty Details', 'ic': Icons.person_outline},
];

List drawer = [
  {'txt': 'Apply Leave', 'ic': Icons.access_time},
  {'txt': 'Hostel Apply', 'ic': Icons.home_work_outlined},
  {'txt': 'Fees', 'ic': Icons.money},
  {'txt': 'Log Out', 'ic': Icons.logout},
];
