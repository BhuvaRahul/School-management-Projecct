import 'package:global_knowledge_school/common_package.dart';

class SplahScreen extends StatefulWidget {
  const SplahScreen({Key? key}) : super(key: key);

  @override
  State<SplahScreen> createState() => _SplahScreenState();
}

class _SplahScreenState extends State<SplahScreen> {
  @override
  void initState() {
    super.initState();
    navigateToHomePage();
  }

  void navigateToHomePage() async {
    await Future.delayed(
      const Duration(seconds: 5),
    );
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const EnterPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: Screens.height(context) * 0.13,
                  width: Screens.width(context) * 0.3,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 14,
                          color: Colors.grey,
                        )
                      ],
                      color: green300,
                      borderRadius: const BorderRadius.only(
                        bottomRight: Radius.circular(100),
                        // bottomLeft: Radius.circular(100),
                      )),
                ),
                const CircleAvatar(
                  radius: 40,
                  backgroundImage: AssetImage('assets/images/hand1.png'),
                ),
                Container(
                  height: Screens.height(context) * 0.13,
                  width: Screens.width(context) * 0.3,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 14,
                          color: Colors.grey,
                        )
                      ],
                      color: green300,
                      borderRadius: const BorderRadius.only(
                        // bottomRight: Radius.circular(100),
                        bottomLeft: Radius.circular(101),
                      )),
                )
              ],
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const CircleAvatar(
                    radius: 100,
                    backgroundImage:
                        AssetImage('assets/images/school logo.png'),
                    backgroundColor: white,
                  ),
                  Text(
                    global,
                    style: headingStyle(),
                  ),
                  Text(high, style: commonStyle(fontWeights: FontWeight.bold)),
                ],
              ),
            ),
            Container(
              height: Screens.height(context) * 0.31,
              decoration: BoxDecoration(
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey,
                  )
                ],
                color: green300,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(300),
                  topRight: Radius.circular(300),
                ),
                image: const DecorationImage(
                    image: AssetImage('assets/images/schhh.png'),
                    fit: BoxFit.fill),
              ),
            )
          ],
        ),
      ),
    );
  }
}
