import 'package:global_knowledge_school/common_package.dart';

class GlobalSchool extends StatefulWidget {
  const GlobalSchool({Key? key}) : super(key: key);

  @override
  State<GlobalSchool> createState() => _GlobalSchoolState();
}

class _GlobalSchoolState extends State<GlobalSchool> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: green300,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const CircleAvatar(
                backgroundColor: white,
                radius: 27,
                child: Image(
                  image: AssetImage('assets/images/school logo.png'),
                ),
              ),
              SizedBox(width: Screens.width(context) * 0.03),
              AutoSizeText(highSchool,
                  presetFontSizes: const [23, 22, 20],
                  style: headingStyle(styleColor: black)
                //TextStyle(color:Colors.black),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 10),
              CarouselSlider.builder(
                itemCount: school.length,
                itemBuilder: (context, index, ib) => Image(
                  image: AssetImage(school[index]['image']),
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.high,
                ),
                options: CarouselOptions(
                  enlargeCenterPage: true,
                  height: Screens.height(context) * 0.32,
                  autoPlay: true,
                  autoPlayAnimationDuration: const Duration(seconds: 2),
                ),
              ),
              SizedBox(height: Screens.height(context) * 0.02),
              Stack(
                children: [
                  Container(
                    height: Screens.height(context) * 0.478,
                    width: Screens.width(context) * 0.95,
                    margin: const EdgeInsets.only(top: 20),
                    decoration: BoxDecoration(
                        color: black12,
                        border: Border.all(color: black, width: 2)),
                    child: Column(
                      children: [
                        SizedBox(height: Screens.height(context) * 0.076),
                        Container(
                          height: Screens.height(context) * 0.08,
                          width: Screens.width(context) * 0.89,
                          color: white,
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: lables(
                                lable: admission2022,
                                style: commonStyle(),
                                presetSize: [19, 18, 17]),
                          ),
                        ),
                        SizedBox(height: Screens.height(context) * 0.013),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                    const AdmissionApply()));
                          },
                          child: Container(
                            height: Screens.height(context) * 0.08,
                            width: Screens.width(context) * 0.89,
                            color: white,
                            alignment: Alignment.center,
                            child: Row(
                              children: [
                                SizedBox(width: Screens.width(context) * 0.04),
                                Icon(icRequestPageOutlined, color: red),
                                lables(
                                    lable: onlineAdForm,
                                    textColor: red,
                                    presetSize: [19, 17, 16]),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: Screens.height(context) * 0.013),
                        GestureDetector(
                          onTap: () {},
                          child: Container(
                            height: Screens.height(context) * 0.08,
                            width: Screens.width(context) * 0.89,
                            color: white,
                            alignment: Alignment.center,
                            child: Row(
                              children: [
                                SizedBox(width: Screens.width(context) * 0.04),
                                Icon(
                                  icRequestPageOutlined,
                                  color: red,
                                ),
                                lables(
                                    lable: stepProcesses,
                                    presetSize: [19, 17, 15],
                                    textColor: red)
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: Screens.height(context) * 0.013),
                        Container(
                          height: Screens.height(context) * 0.1,
                          width: Screens.width(context) * 0.89,
                          color: white,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(admissionQuery, style: commonStyle()),
                              Row(
                                children: [
                                  SizedBox(
                                      width: Screens.width(context) * 0.05),
                                  Text(
                                    phoneNo,
                                    style: commonStyle(fontSizes: 15),
                                  ),
                                  Text(phoneNo1,
                                      style: commonStyle(fontSizes: 15))
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 28.0, bottom: 40),
                    child: Container(
                      height: Screens.height(context) * 0.082,
                      width: Screens.width(context) * 0.52,
                      decoration: BoxDecoration(
                          color: green300,
                          border: Border.all(color: black, width: 2)),
                      child: Row(
                        children: [
                          Icon(icAccessTime, size: 35),
                          SizedBox(width: Screens.width(context) * 0.05),
                          lables(lable: admission, style: headingStyle()),
                        ],
                      ),
                    ),
                  )
                ],
              ), // Admission
              SizedBox(height: Screens.height(context) * 0.02),
              Stack(
                children: [
                  Container(
                    height: Screens.height(context) * 0.275,
                    width: Screens.width(context) * 0.95,
                    margin: const EdgeInsets.only(top: 20),
                    decoration: BoxDecoration(
                        color: black12,
                        border: Border.all(color: black, width: 2)),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(height: Screens.height(context) * 0.05),
                          ListView.builder(
                            shrinkWrap: true,
                            itemCount: currentNewsDetails.length,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) => Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(10),
                              margin: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  color: yellow50,
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(color: black, width: 2)),
                              child: Text(
                                currentNewsDetails[index]['currentNews'],
                                style: commonStyle(),
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 28.0, bottom: 40),
                    child: Container(
                      height: Screens.height(context) * 0.082,
                      width: Screens.width(context) * 0.62,
                      decoration: BoxDecoration(
                          color: green300,
                          border: Border.all(color: black, width: 2)),
                      child: Row(
                        children: [
                          Icon(icNewsPaperOutlined, size: 35),
                          SizedBox(width: Screens.width(context) * .036),
                          lables(
                            lable: currentNews,
                            style: headingStyle(),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ), // Current News

              SizedBox(height: Screens.height(context) * 0.02),
              Stack(
                children: [
                  Container(
                    height: Screens.height(context) * 0.475,
                    width: Screens.width(context) * 0.95,
                    margin: const EdgeInsets.only(top: 20),
                    decoration: BoxDecoration(
                        color: black12,
                        border: Border.all(color: black, width: 2)),
                    child: Column(
                      children: [
                        SizedBox(height: Screens.height(context) * 0.06),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: Screens.height(context) * 0.11,
                              width: Screens.width(context) * 0.013,
                              color: black,
                            ),
                            Column(
                              children: const [
                                AutoSizeText(
                                  welcome,
                                  presetFontSizes: [19, 17, 16],
                                ),
                                AutoSizeText(
                                  globalKnowledge,
                                  presetFontSizes: [19, 17, 16],
                                )
                              ],
                            ),
                          ],
                        ),
                        const Divider(
                          color: black,
                        ),
                        const Padding(
                          padding: EdgeInsets.all(9.0),
                          child: AutoSizeText(
                            visitText,
                            presetFontSizes: [16, 15, 14],
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.all(9.0),
                          child: AutoSizeText(
                            visitText2,
                            presetFontSizes: [16, 15, 14],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 28.0, bottom: 40),
                    child: Container(
                      height: Screens.height(context) * 0.082,
                      width: Screens.width(context) * 0.52,
                      decoration: BoxDecoration(
                          color: green300,
                          border: Border.all(color: black, width: 2)),
                      child: Row(
                        children: [
                          Icon(icHome, size: 35),
                          SizedBox(width: Screens.width(context) * .036),
                          lables(
                            lable: planVisit,
                            style: headingStyle(),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ), // Plan A Visit
              SizedBox(height: Screens.height(context) * 0.05),
              AutoSizeText(
                amenitiesTitle,
                style: headingStyle(styleSize: 25),
              ),
              const AutoSizeText(
                amenitiesSubTitle,
                presetFontSizes: [16, 15, 14],
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: amenities.length,
                itemBuilder: (context, index) => ListTile(
                  leading: Container(
                    height: Screens.height(context) * 0.2,
                    width: Screens.width(context) * 0.2,
                    decoration: BoxDecoration(
                      color: yellow50,
                      border: Border.all(color: pink, width: 1),
                      borderRadius: const BorderRadius.only(
                        bottomRight: Radius.circular(25),
                        topLeft: Radius.circular(25),
                      ),
                    ),
                    child: Icon(
                      amenities[index]['icon'],
                      size: 35,
                      color: black,
                    ),
                  ),
                  title: Text(
                    amenities[index]['title'],
                    style: const TextStyle(color: pink, fontSize: 19),
                  ),
                  subtitle: AutoSizeText(
                    amenities[index]['subtitle'],
                    presetFontSizes: const [14, 15, 13],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => data[index].ame),
                    );
                  },
                ),
              ),
              SizedBox(height: Screens.height(context) * 0.02),
              GridView.builder(
                shrinkWrap: true,
                itemCount: abt.length,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 8,
                    childAspectRatio: 8 / 7,
                    mainAxisSpacing: 8),
                itemBuilder: (context, index) => Container(
                  decoration: BoxDecoration(border: Border.all(color: black)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      CircleAvatar(
                        radius: 39,
                        backgroundImage: AssetImage(abt[index]['img']),
                      ),
                      Text(
                        abt[index]['tlt'],
                        style: commonStyle(fontColor: pink),
                      ),
                      Text(
                        abt[index]['stlt'],
                        style: commonStyle(fontColor: pink),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: Screens.height(context) * 0.02),
              Padding(
                padding: const EdgeInsets.only(right: 159.0),
                child: Text(
                  whyChooseUs,
                  style: headingStyle(),
                ),
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: why.length,
                itemBuilder: (context, index) => ExpansionTile(
                  title: Text(
                    why[index]['choose'],
                    style: commonStyle(fontColor: blue),
                  ),
                  trailing: Icon(
                    icAdd,
                    color: pink,
                  ),
                  children: [
                    lables(lable: why[index]['txt1']),
                    lables(lable: why[index]['txt2'])
                  ],
                ),
              ),
              SizedBox(height: Screens.height(context) * 0.01),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  lables(lable: mission, style: headingStyle()),
                  lables(lable: missionData),
                  SizedBox(height: Screens.height(context) * 0.01),
                  lables(lable: vision, style: headingStyle()),
                  lables(lable: visionData),
                  SizedBox(height: Screens.height(context) * 0.01),
                  lables(lable: objective, style: headingStyle()),
                  lables(lable: objectiveData),
                  lables(lable: objectiveData2),
                  lables(lable: objectiveData3),
                ],
              ),
              ExpansionTile(
                title: const Text(feeStructure),
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(fee.length, (i) {
                      return GestureDetector(
                        onTap: () {
                          if (i == 0) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const First()));
                          }
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 2),
                          height: Screens.height(context) * 0.075,
                          width: double.infinity,
                          color: yellow,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 13.0),
                            child: Text(
                              fee[i]['fees'],
                              style: commonStyle(fontSizes: 17),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
