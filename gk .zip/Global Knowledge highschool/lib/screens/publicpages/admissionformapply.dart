import 'package:global_knowledge_school/common_package.dart';

class AdmissionApply extends StatefulWidget {
  const AdmissionApply({Key? key}) : super(key: key);

  @override
  State<AdmissionApply> createState() => _AdmissionApplyState();
}

class _AdmissionApplyState extends State<AdmissionApply> {
  TextEditingController txtStudNameController = TextEditingController();
  TextEditingController txtStudClassController = TextEditingController();
  TextEditingController txtStudFatherController = TextEditingController();
  TextEditingController txtStudPhoneController = TextEditingController();
  TextEditingController txtStudPhone1Controller = TextEditingController();
  TextEditingController txtStudBirthController = TextEditingController();
  TextEditingController txtStudAddressController = TextEditingController();
  TextEditingController txtStudCityController = TextEditingController();
  TextEditingController txtStudPinCodeController = TextEditingController();
  TextEditingController txtStudEmailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Text(
        highSchool,
        style: headingStyle(),
      )),
      body: SingleChildScrollView(
        child: Column(
          children: [
            commonTextFormField(
                controller: txtStudNameController,
                hintTex: studentName,
                prefixIcons: Icon(icPerson)),
            commonTextFormField(
                controller: txtStudClassController,
                hintTex: classApply,
                prefixIcons: Icon(icHome)),
            commonTextFormField(
                controller: txtStudFatherController,
                hintTex: fatherName,
                prefixIcons: Icon(icPerson)),
            Row(
              children: [
                Expanded(
                  child: commonTextFormField(
                      controller: txtStudPhoneController,
                      hintTex: phone,
                      keyBordTypes: TextInputType.phone,
                      prefixIcons: Icon(icPhoneAndroid)),
                ),
                Expanded(
                  child: commonTextFormField(
                      controller: txtStudPhone1Controller,
                      hintTex: phone2,
                      keyBordTypes: TextInputType.phone,
                      prefixIcons: Icon(icPhoneAndroid)),
                ),
              ],
            ),
            commonTextFormField(
                controller: txtStudBirthController,
                hintTex: dob,
                keyBordTypes: TextInputType.number,
                prefixIcons: Icon(icDateRange)),
            commonTextFormField(
                controller: txtStudAddressController,
                hintTex: address,
                prefixIcons: Icon(icAddRoad)),
            Row(
              children: [
                Expanded(
                  child: commonTextFormField(
                      controller: txtStudCityController,
                      hintTex: city,
                      prefixIcons: Icon(icRealEstateAgent)),
                ),
                Expanded(
                  child: commonTextFormField(
                      controller: txtStudPinCodeController,
                      hintTex: pinCode,
                      keyBordTypes: TextInputType.phone,
                      prefixIcons: Icon(icLocationCity)),
                ),
              ],
            ),
            commonTextFormField(
                controller: txtStudEmailController,
                hintTex: email,
                keyBordTypes: TextInputType.emailAddress,
                prefixIcons: Icon(icEmailOutLined)),
            commonButtons(
                lable: const Text(submit),
                onPress: () {
                  studApply.add({
                    "name": txtStudNameController.text,
                    "class": txtStudClassController.text,
                    "father": txtStudFatherController.text,
                    "phone": txtStudPhoneController.text,
                    "phone1": txtStudPhone1Controller.text,
                    "birth": txtStudBirthController.text,
                    "address": txtStudAddressController.text,
                    "city": txtStudCityController.text,
                    "pinCode": txtStudPinCodeController.text,
                    "email": txtStudEmailController.text,
                  });
                  Navigator.pop(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const GlobalSchool()));
                })
          ],
        ),
      ),
    );
  }
}

List<Map> studApply = [];

class AdmissionApplyDetails extends StatefulWidget {
  const AdmissionApplyDetails({Key? key}) : super(key: key);

  @override
  State<AdmissionApplyDetails> createState() => _AdmissionApplyDetailsState();
}

class _AdmissionApplyDetailsState extends State<AdmissionApplyDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Text(
        admissionApplyDetails,
        style: headingStyle(),
      )),
      body: ListView.builder(
        itemCount: studApply.length,
        itemBuilder: (context, index) => Card(
          elevation: 3,
          shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ApplyDetails(index: index)));
            },
            child: Container(
              height: Screens.height(context) * 0.075,
              decoration: BoxDecoration(
                color: yellow50,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(13.0),
                child: Text(
                  studApply[index]['name'],
                  style: subTitleStyle(),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class ApplyDetails extends StatefulWidget {
  int index;

  ApplyDetails({Key? key, required this.index}) : super(key: key);

  @override
  State<ApplyDetails> createState() => _ApplyDetailsState();
}

class _ApplyDetailsState extends State<ApplyDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
        lable: Text(
          studApply[widget.index]['name'],
          style: headingStyle(),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            smallContainer(
              width1: 60,
              text: Text(studApply[widget.index]['name']),
              label: Text(name, style: subTitleStyle(fontColor: grey)),
            ),
            smallContainer(
              width1: 210,
              text: Text(studApply[widget.index]['class']),
              label: Text(classApply, style: subTitleStyle(fontColor: grey)),
            ),
            smallContainer(
              width1: 110,
              text: Text(studApply[widget.index]['father']),
              label: Text(fatherName, style: subTitleStyle(fontColor: grey)),
            ),
            Row(
              children: [
                smallContainer(
                  width1: 100,
                  width: 150,
                  text: Text(studApply[widget.index]['phone']),
                  label: Text(phone, style: subTitleStyle(fontColor: grey)),
                ),
                smallContainer(
                  width1: 100,
                  width: 150,
                  text: Text(studApply[widget.index]['phone1']),
                  label: Text(phone2, style: subTitleStyle(fontColor: grey)),
                ),
              ],
            ),
            smallContainer(
              width1: 60,
              // width: 150,
              // left: 35,
              text: Text(studApply[widget.index]['birth']),
              label: Text(dob1, style: subTitleStyle(fontColor: grey)),
            ),
            smallContainer(
              width1: 80,
              text: Text(studApply[widget.index]['address']),
              label: Text(address, style: subTitleStyle(fontColor: grey)),
            ),
            smallContainer(
                width1: 60,
                text: Text(studApply[widget.index]['city']),
                label: Text(
                  city,
                  style: subTitleStyle(fontColor: grey),
                )),
            smallContainer(
                width1: 80,
                text: Text(studApply[widget.index]['pinCode']),
                label: Text(
                  pinCode,
                  style: subTitleStyle(fontColor: grey),
                )),
            smallContainer(
              width1: 60,
              text: Text(studApply[widget.index]['email']),
              label: Text(
                email,
                style: subTitleStyle(fontColor: grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
