import 'package:global_knowledge_school/common_package.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/add_student/add_student_details.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/show_student_details/show_student_details.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/student_profile/student_profiles.dart';

// ignore: must_be_immutable
class StudentDetails extends StatefulWidget {
  int sIndex;

  StudentDetails({Key? key, required this.sIndex}) : super(key: key);

  @override
  State<StudentDetails> createState() => _StudentDetailsState();
}

class _StudentDetailsState extends State<StudentDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Text(
        'Student Details',
        style: headingStyle(),
      )),
      body: GridView.builder(
          itemCount: stdList.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisExtent: 50,
              mainAxisSpacing: 3,
              crossAxisSpacing: 3),
          itemBuilder: (context, index) => GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddStudent(i: index),
                      ));
                },
                child: Container(
                  margin: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                      color: yellow50,
                      border: Border.all(),
                      borderRadius: BorderRadius.circular(20)),
                  alignment: Alignment.center,
                  child: Text(stdList[index]['std'].toString()),
                ),
              )),
    );
  }
}

// ignore: must_be_immutable
class SDetails extends StatefulWidget {
  int ind;

  SDetails({Key? key, required this.ind}) : super(key: key);

  @override
  State<SDetails> createState() => _SDetailsState();
}

class _SDetailsState extends State<SDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
        lable: Text(
          studentDetails,
          style: headingStyle(),
        ),
      ),
      body: ListView.builder(
        scrollDirection: Axis.vertical,
        itemCount: stdList[widget.ind]['studentList'].length,
        itemBuilder: (context, index) => GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => StudentName(
                  data: stdList[widget.ind]['studentList'],
                  index: index,
                ),
              ),
            );
          },
          child: Card(
            elevation: 3,
            shape: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              height: Screens.height(context) * 0.072,
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                color: yellow50,
                borderRadius: BorderRadius.circular(20),
              ),
              padding: const EdgeInsets.all(12),
              child: Text(
                stdList[widget.ind]['studentList'][index]['name'],
                style: commonStyle(),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
