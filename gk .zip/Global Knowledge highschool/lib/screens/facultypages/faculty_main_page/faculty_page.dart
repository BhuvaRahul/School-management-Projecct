import 'package:global_knowledge_school/common_package.dart';

class FacultyPage extends StatefulWidget {
  const FacultyPage({Key? key}) : super(key: key);

  @override
  State<FacultyPage> createState() => _FacultyPageState();
}

class _FacultyPageState extends State<FacultyPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: green300,
        centerTitle: true,
        leading: commonAppContainer(),
        title:  const Text(
          faculty,
          style: TextStyle(
              color: Colors.black, fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
      endDrawer: Drawer(
        child: Column(
          children: [
            const DrawerHeader(
                child: CircleAvatar(
              radius: 60,
              backgroundColor: white,
              backgroundImage: AssetImage('assets/images/school logo.png'),
            )),
            ListView.separated(
              itemCount: drawerLs.length,
                shrinkWrap: true,
                separatorBuilder: (context, index) =>
                    const Divider(thickness: 1),
                itemBuilder: (context, index) => ListTile(
                      leading: Icon(drawerLs[index]['ic']),
                      title: Text(drawerLs[index]['text'], style: commonStyle()),
                      onTap: () {
                        if (index == 0) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => StudentDetails(
                                  sIndex: index,
                                ),
                              ));
                        }
                        if (index == 1) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const FacultyDetails(),
                              ));
                        }
                        if (index == 3) {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const EnterPage()));
                        }
                      },
                    ),
                )
          ],
        ),
      ),
      body: SafeArea(
        child: GridView.builder(
          itemCount: facultyLs.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 1.33,
          ),
          shrinkWrap: true,
          itemBuilder: (BuildContext context, int index) => Column(
            children: [
              verticalSpace(vertical: Screens.height(context) * 0.02),
              GestureDetector(
                onTap: () {
                  if (index == 0) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => HDetails(i: index)));
                  }
                  if (index == 1) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const FacultyTimeTables(),
                        ));
                  }
                  if (index == 2) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const StudentLeave()));
                  }
                  if (index == 4) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => StudentDetails(
                            sIndex: index,
                          ),
                        ));
                  }
                  if (index == 5) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const FacultyDetails(),
                        ));
                  }
                },
                child: Card(
                  elevation: 10,
                  shape: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Container(
                    height: 90,
                    width: Screens.width(context)*0.43,
                    decoration: BoxDecoration(
                        color: green300,
                        borderRadius: BorderRadius.circular(20)),
                    child: Icon(facultyLs[index]['img'], size: 50),
                  ),
                ),
              ),
              Text(facultyLs[index]['txt'], style: commonStyle()),
            ],
          ),
        ),
      ),
    );
  }
}

List<Map> facultyLs = [
  {'txt': 'Home Work', 'img': Icons.maps_home_work},
  {'txt': 'Time Table', 'img': Icons.table_chart},
  {'txt': 'Student Leave', 'img': Icons.time_to_leave},
  {'txt': 'Attendances', 'img': Icons.tab},
  {'txt': 'Student Details', 'img': Icons.group},
  {'txt': 'Faculty Details', 'img': Icons.person},
];

List drawerLs = [
  {'text': 'Student Details', 'ic': Icons.group},
  {'text': 'Faculty Details', 'ic': Icons.person},
  {'text': 'Log Out', 'ic': Icons.logout},
];
