import 'package:global_knowledge_school/common_package.dart';

// ignore: must_be_immutable
class StudentName extends StatefulWidget {
  List data;
  int index;

  StudentName({Key? key, required this.data, required this.index})
      : super(key: key);

  @override
  State<StudentName> createState() => _StudentNameState();
}

class _StudentNameState extends State<StudentName> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Row(
        children: [
          Text(widget.data[widget.index]['name'], style: headingStyle()),
          horizontalSpace(horizontal: Screens.width(context) * 0.02),
          Text(widget.data[widget.index]['surname'], style: headingStyle()),
        ],
      )),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: CircleAvatar(
                radius: 60,
                backgroundColor: white,
                backgroundImage: AssetImage('assets/images/campus.png'),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                smallContainer(
                    width1: 70,
                    width: 150,
                    text: Text(widget.data[widget.index]['name'],
                        style: subTitleStyle()),
                    label: const Text(facultyName)),
                smallContainer(
                    width1: 70,
                    width: 150,
                    text: Text(widget.data[widget.index]['surname'],
                        style: subTitleStyle()),
                    label: const Text(surname))
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: smallContainer(
                      width1: 50,
                      width: 150,
                      text: Text(widget.data[widget.index]['std'],
                          style: subTitleStyle()),
                      label: const Text(std)),
                ),
                Expanded(
                  child: smallContainer(
                      width1: 50,
                      width: 150,
                      text: Text(widget.data[widget.index]['gender']),
                      label: const Text(studentGender)),
                ),
              ],
            ),
            smallContainer(
              width1: 55,
              label: const Text(rollNo),
              text: Text(widget.data[widget.index]['rollNumber'],
                  style: subTitleStyle()),
            ),
            smallContainer(
                width1: 110,
                text: Text(widget.data[widget.index]['mobile']),
                label: const Text(studentMobileNumber)),
            smallContainer(
                width1: 60,
                text: Text(widget.data[widget.index]['address']),
                label: const Text(address)),
          ],
        ),
      ),
    );
  }
}
