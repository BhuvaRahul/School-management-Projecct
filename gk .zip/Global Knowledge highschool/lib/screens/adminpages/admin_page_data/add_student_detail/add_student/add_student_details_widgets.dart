import 'package:global_knowledge_school/common_package.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/add_student/add_student_details.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/student_profile/student_profiles.dart';

Widget sListViewBuilder() => ListView.builder(
      shrinkWrap: true,
      itemCount: stdList.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, index) => Dismissible(
        key: ObjectKey(stdList[index]),
        onDismissed: (direction) {
          stdList.removeAt(index);
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Delete....'),
            duration: Duration(seconds: 1),
          ));
        },
        direction: DismissDirection.endToStart,
        background: slideLeftBackground(),
        child: GestureDetector(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => StudentName(
                    index: index,
                    data: const [],
                  ),
                ));
          },
          child: Card(
            elevation: 3,
            margin: const EdgeInsets.all(3),
            shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
            child: Container(
              height: Screens.height(context) * 0.072,
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                  color: yellow50, borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.all(12),
              child: Text(stdList[index]['name'], style: commonStyle()),
            ),
          ),
        ),
      ),
    );

Widget slideLeftBackground() {
  return Container(
    color: red,
    child: Align(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          Icon(
            icDelete,
            color: white,
          ),
          const Text(
            " Delete",
            style: TextStyle(
              color: white,
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.right,
          ),
          horizontalSpace(horizontal: 20),
        ],
      ),
      alignment: Alignment.centerRight,
    ),
  );
}
