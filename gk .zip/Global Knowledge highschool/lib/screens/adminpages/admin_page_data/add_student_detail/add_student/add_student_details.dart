import 'package:global_knowledge_school/common_package.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/show_student_details/show_student_details.dart';

class Standard extends StatefulWidget {
  const Standard({Key? key}) : super(key: key);

  @override
  State<Standard> createState() => _StandardState();
}

class _StandardState extends State<Standard> {
  TextEditingController txtNameController = TextEditingController();
  TextEditingController txtSurnameController = TextEditingController();
  TextEditingController txtStdController = TextEditingController();
  TextEditingController txtClassController = TextEditingController();
  TextEditingController txtRollNumberController = TextEditingController();
  TextEditingController txtMobileController = TextEditingController();
  TextEditingController txtAddressController = TextEditingController();
  TextEditingController txtUsernameController = TextEditingController();
  TextEditingController txtPasswordController = TextEditingController();
  final key1 = GlobalKey<FormState>();
  bool pasword = true;
  String? selectedStandard;
  String? selectedGender;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Text(
        addStudent,
        style: headingStyle(),
      )),
      floatingActionButton: commonFloatingActionButton(onPress: () {
        showDialog(
          context: context,
          builder: (context) => SingleChildScrollView(
            child: AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) => Form(
                  key: key1,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: commonTextFormField(
                              hintTex: studentFullName,
                              controller: txtNameController,
                            ),
                          ),
                          Expanded(
                            child: commonTextFormField(
                                controller: txtSurnameController,
                                hintTex: surname),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          const SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            value: selectedStandard,
                            items: [
                              for (int i = 0; i < stdList.length; i++)
                                DropdownMenuItem(
                                  child: Text(stdList[i]['std']),
                                  value: stdList[i]['std'],
                                )
                            ],
                            /*stdList
                                .map((e) => DropdownMenuItem(
                                      child: Text(e),
                                      value: e,
                                    ))
                                .toList(),*/
                            elevation: 6,
                            onChanged: (value) => setState(() {
                              selectedStandard = value.toString();
                            }),
                            hint: const Text(std),
                          ),
                          const SizedBox(
                            width: 35,
                          ),
                          DropdownButton(
                            value: selectedGender,
                            items: gender
                                .map((e) => DropdownMenuItem(
                                      child: Text(e),
                                      value: e,
                                    ))
                                .toList(),
                            onChanged: (value) {
                              selectedGender = value.toString();
                            },
                            hint: const Text(studentGender),
                          ),
                        ],
                      ),
                      commonTextFormField(
                          controller: txtRollNumberController,
                          hintTex: studentRollNumber,
                          keyBordTypes: TextInputType.number),
                      commonTextFormField(
                          controller: txtMobileController,
                          hintTex: studentMobileNumber,
                          keyBordTypes: TextInputType.phone),
                      commonTextFormField(
                        controller: txtAddressController,
                        hintTex: studentAddress,
                      ),
                      commonTextFormField(
                        controller: txtUsernameController,
                        hintTex: studentUserName,
                      ),
                      commonTextFormField(
                        textInputAction: TextInputAction.done,
                        controller: txtPasswordController,
                        obsecurText: pasword,
                        hintTex: studentPassword,
                        sufixIcons: IconButton(
                          onPressed: () {
                            setState(() {
                              pasword = !pasword;
                            });
                          },
                          icon: Icon(pasword ? icVisibiltyOff : icVisibilty,
                              color: grey),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                commonButtons(
                    lable: Text(
                      cancel,
                      style: commonStyle(),
                    ),
                    onPress: () {
                      setState(() {
                        Navigator.pop(context);
                      });
                    }),
                SizedBox(width: Screens.width(context) * 0.01),
                commonButtons(
                  lable: Text(submit, style: commonStyle()),
                  onPress: () {
                    for (int i = 0; i < stdList.length; i++) {
                      if (selectedStandard == stdList[i]['std']) {
                        stdList[i]['studentList'].add({
                          "name": txtNameController.text,
                          "surname": txtSurnameController.text,
                          'std': selectedStandard,
                          'gender': selectedGender,
                          'rollNumber': txtRollNumberController.text,
                          'mobile': txtMobileController.text,
                          'address': txtAddressController.text,
                          'username': txtUsernameController.text,
                          'password': txtPasswordController.text,
                        });
                      }
                    }
                    txtNameController.clear();
                    txtSurnameController.clear();
                    txtRollNumberController.clear();
                    txtMobileController.clear();
                    txtAddressController.clear();
                    txtUsernameController.clear();
                    txtPasswordController.clear();
                    selectedStandard = null;
                    selectedGender = null;
                    setState(() {
                      Navigator.pop(context);
                    });
                  },
                ),
              ],
            ),
          ),
        );
        setState(() {});
      }),
      body: SafeArea(
          child: GridView.builder(
        itemCount: stdList.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            mainAxisSpacing: 5,
            crossAxisSpacing: 5,
            mainAxisExtent: 50),
        itemBuilder: (context, index) => GestureDetector(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddStudent(i: index),
                ));
          },
          child: Container(
            margin: const EdgeInsets.all(3),
            decoration: BoxDecoration(
                color: yellow50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all()),
            alignment: Alignment.center,
            child: Text(
              stdList[index]['std'].toString(),
              style: commonStyle(),
            ),
          ),
        ),
      )),
    );
  }
}

List gender = [
  'Male',
  'Female',
  'Other',
];

List<Map> stdList = [
  {'std': '1-A', 'studentList': []},
  {'std': '1-B', 'studentList': []},
  {'std': '1-C', 'studentList': []},
  {'std': '2-A', 'studentList': []},
  {'std': '2-B', 'studentList': []},
  {'std': '2-C', 'studentList': []},
  {'std': '3-A', 'studentList': []},
  {'std': '3-B', 'studentList': []},
  {'std': '3-C', 'studentList': []},
  {'std': '4-A', 'studentList': []},
  {'std': '4-B', 'studentList': []},
  {'std': '4-C', 'studentList': []},
  {'std': '5-A', 'studentList': []},
  {'std': '5-B', 'studentList': []},
  {'std': '5-C', 'studentList': []},
  {'std': '6-A', 'studentList': []},
  {'std': '6-B', 'studentList': []},
  {'std': '6-C', 'studentList': []},
  {'std': '7-A', 'studentList': []},
  {'std': '7-B', 'studentList': []},
  {'std': '7-C', 'studentList': []},
  {'std': '8-A', 'studentList': []},
  {'std': '8-B', 'studentList': []},
  {'std': '8-C', 'studentList': []},
  {'std': '9-A', 'studentList': []},
  {'std': '9-B', 'studentList': []},
  {'std': '9-C', 'studentList': []},
  {'std': '10-A', 'studentList': []},
  {'std': '10-B', 'studentList': []},
  {'std': '10-C', 'studentList': []},
  {'std': '11 Com-A', 'studentList': []},
  {'std': '11 Com-B', 'studentList': []},
  {'std': '11 Com-C', 'studentList': []},
  {'std': '11 Sci-A', 'studentList': []},
  {'std': '11 Sci-B', 'studentList': []},
  {'std': '11 Sci-C', 'studentList': []},
  {'std': '12 Com-A', 'studentList': []},
  {'std': '12 Com-B', 'studentList': []},
  {'std': '12 Com-C', 'studentList': []},
  {'std': '12 Sci-A', 'studentList': []},
  {'std': '12 Sci-B', 'studentList': []},
  {'std': '12 Sci-C', 'studentList': []},
];
