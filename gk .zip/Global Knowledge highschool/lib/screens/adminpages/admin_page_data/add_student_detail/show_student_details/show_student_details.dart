import 'package:global_knowledge_school/common_package.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/add_student/add_student_details.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_student_detail/student_profile/student_profiles.dart';

// ignore: must_be_immutable
class AddStudent extends StatefulWidget {
  int i;

  AddStudent({Key? key, required this.i}) : super(key: key);

  @override
  State<AddStudent> createState() => _AddStudentState();
}

class _AddStudentState extends State<AddStudent> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Text(
            studentDetails,
            style: headingStyle(),
          )),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: stdList[widget.i]['studentList'].isEmpty
                  ? Container()
                  : ListView.builder(
                itemCount: stdList[widget.i]['studentList'].length,
                scrollDirection: Axis.vertical,
                itemBuilder: (context, index) =>
                    Dismissible(
                      key: ObjectKey(stdList[widget.i]['studentList'][index]),
                      onDismissed: (direction) {
                        stdList[widget.i]['studentList'].removeAt(index);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Delete....'),
                            duration: Duration(seconds: 1),
                          ),
                        );
                      },
                      direction: DismissDirection.endToStart,
                      background: slideLeftBackground(),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    StudentName(
                                        data: stdList[widget.i]['studentList'],
                                        index: index),
                              ));
                        },
                        child: Card(
                          elevation: 3,
                          shape: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20)),
                          child: Container(
                            height: Screens.height(context) * 0.072,
                            alignment: Alignment.centerLeft,
                            decoration: BoxDecoration(
                                color: yellow50,
                                borderRadius: BorderRadius.circular(20)),
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Text(
                                  stdList[widget.i]['studentList'][index]
                                  ['name'],
                                  style: subTitleStyle()),
                            ),
                          ),
                        ),
                      ),
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget slideLeftBackground() {
  return Container(
    color: Colors.red,
    child: Align(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: const <Widget>[
          Icon(
            Icons.delete,
            color: Colors.white,
          ),
          Text(
            " Delete",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.right,
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
      alignment: Alignment.centerRight,
    ),
  );
}
