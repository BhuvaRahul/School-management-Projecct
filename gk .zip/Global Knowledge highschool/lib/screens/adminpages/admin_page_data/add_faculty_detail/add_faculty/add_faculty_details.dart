import 'package:global_knowledge_school/common_package.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_faculty_detail/show_faculty_details/show_faculty_details.dart';

class Subject extends StatefulWidget {
  const Subject({Key? key}) : super(key: key);

  @override
  State<Subject> createState() => _SubjectState();
}

class _SubjectState extends State<Subject> {
  TextEditingController txtSurnameController = TextEditingController();
  TextEditingController txtNameController = TextEditingController();
  TextEditingController txtMobileController = TextEditingController();
  TextEditingController txtEmailController = TextEditingController();
  TextEditingController txtUsernameController = TextEditingController();
  TextEditingController txtPasswordController = TextEditingController();
  final key1 = GlobalKey<FormState>();
  bool pasword = true;
  String? selectedDepartment;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Text(
        'Faculties',
        style: headingStyle(),
      )),
      floatingActionButton: commonFloatingActionButton(onPress: () {
        setState(() {});
        showDialog(
          context: context,
          builder: (context) => SingleChildScrollView(
            child: AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) => Form(
                  key: key1,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: commonTextFormField(
                              hintTex: facultyName,
                              controller: txtNameController,
                            ),
                          ),
                          Expanded(
                              child: commonTextFormField(
                                  controller: txtSurnameController,
                                  hintTex: surname))
                        ],
                      ),
                      commonTextFormField(
                          controller: txtMobileController,
                          hintTex: facultyMobile,
                          keyBordTypes: TextInputType.number),
                      commonTextFormField(
                          controller: txtEmailController,
                          hintTex: facultyEmail,
                          keyBordTypes: TextInputType.emailAddress),
                      DropdownButton(
                        value: selectedDepartment,
                        items: [
                          for (int i = 0; i < subject.length; i++)
                            DropdownMenuItem(
                              child: Text(subject[i]['sub']),
                              value: subject[i]['sub'],
                            )
                        ],
                        onChanged: (value) {
                          setState(() {
                            selectedDepartment = value.toString();
                          });
                        },
                        elevation: 6,
                        hint: const Text(facultyDepartment),
                      ),
                      commonTextFormField(
                        controller: txtUsernameController,
                        hintTex: facultyUsername,
                      ),
                      commonTextFormField(
                        textInputAction: TextInputAction.done,
                        controller: txtPasswordController,
                        obsecurText: pasword,
                        hintTex: facultyPassword,
                        sufixIcons: IconButton(
                          onPressed: () {
                            pasword = !pasword;
                            setState(() {});
                          },
                          icon: Icon(
                            pasword ? icVisibiltyOff : icVisibilty,
                            color: grey,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                commonButtons(
                    lable: Text(
                      cancel,
                      style: commonStyle(),
                    ),
                    onPress: () {
                      setState(() {
                        Navigator.pop(context);
                      });
                    }),
                horizontalSpace(horizontal: Screens.width(context) * 0.01),
                commonButtons(
                  lable: Text(submit, style: commonStyle()),
                  onPress: () {
                    for (int i = 0; i < subject.length; i++) {
                      if (selectedDepartment == subject[i]['sub']) {
                        subject[i]['subList'].add({
                          'name': txtNameController.text,
                          'surname': txtSurnameController.text,
                          'mobile': txtMobileController.text,
                          'email': txtEmailController.text,
                          'department': selectedDepartment,
                          'username': txtUsernameController.text,
                          'password': txtPasswordController.text,
                        });
                      }
                    }

                    setState(() {
                      txtUsernameController.clear();
                      txtSurnameController.clear();
                      txtPasswordController.clear();
                      txtEmailController.clear();
                      txtMobileController.clear();
                      Navigator.pop(context);
                    });
                  },
                ),
              ],
            ),
          ),
        );
      }),
      body: GridView.builder(
        shrinkWrap: true,
        itemCount: subject.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisExtent: 60,
        ),
        itemBuilder: (context, index) => GestureDetector(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => AddFaculty(idx: index)));
          },
          child: Container(
            decoration: BoxDecoration(
                color: yellow50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all()),
            margin: const EdgeInsets.all(4),
            child: Center(
                child: Text(
              subject[index]['sub'].toString(),
              style: commonStyle(),
            )),
          ),
        ),
      ),
    );
  }
}

List<Map> subject = [
  {'sub': 'Gujarati', 'subList': []},
  {'sub': 'Hindi', 'subList': []},
  {'sub': 'Sanskrit', 'subList': []},
  {'sub': 'Science', 'subList': []},
  {'sub': 'Maths', 'subList': []},
  {'sub': 'English', 'subList': []},
  {'sub': 'S.S', 'subList': []},
  {'sub': 'Computer', 'subList': []},
  {'sub': 'Draw', 'subList': []},
  {'sub': 'P.T', 'subList': []},
  {'sub': 'Biology', 'subList': []},
  {'sub': 'Physics', 'subList': []},
  {'sub': 'Chemistry', 'subList': []},
  {'sub': 'Stat', 'subList': []},
  {'sub': 'Account', 'subList': []},
  {'sub': 'Economics', 'subList': []},
  {'sub': 'S.P & CC', 'subList': []},
];
