import 'package:global_knowledge_school/common_package.dart';

// ignore: must_be_immutable
class FacultyName extends StatefulWidget {
  int index;
  List fData;

  FacultyName({Key? key, required this.index, required this.fData})
      : super(key: key);

  @override
  State<FacultyName> createState() => _FacultyNameState();
}

class _FacultyNameState extends State<FacultyName> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
          lable: Row(
        children: [
          Text(widget.fData[widget.index]['name'], style: headingStyle()),
          horizontalSpace(horizontal: Screens.width(context) * 0.02),
          Text(widget.fData[widget.index]['surname'], style: headingStyle())
        ],
      )),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: CircleAvatar(
                radius: 60,
                backgroundColor: white,
                backgroundImage: AssetImage('assets/images/school logo.png'),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                smallContainer(
                  width: 150,
                  width1: 85,
                  label: const Text(facultyName),
                  text: Text(widget.fData[widget.index]['name'],
                      style: subTitleStyle()),
                ),
                smallContainer(
                    width: 150,
                    width1: 60,
                    label: const Text(surname),
                    text: Text(widget.fData[widget.index]['surname'],
                        style: subTitleStyle()))
              ],
            ),
            smallContainer(
              width1: 110,
              label: const Text(facultyMobile),
              text: Text(widget.fData[widget.index]['mobile'],
                  style: subTitleStyle()),
            ),
            smallContainer(
              width1: 45,
              label: const Text(facultyEmail),
              text: Text(widget.fData[widget.index]['email'],
                  style: subTitleStyle()),
            ),
            smallContainer(
              width1: 80,
              text: Text(widget.fData[widget.index]['department'],
                  style: subTitleStyle()),
              label: const Text(facultyDepartment),
            ),
          ],
        ),
      ),
    );
  }
}
