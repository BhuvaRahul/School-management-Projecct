import 'package:global_knowledge_school/common_package.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_faculty_detail/add_faculty/add_faculty_details.dart';
import 'package:global_knowledge_school/screens/adminpages/admin_page_data/add_faculty_detail/faculty_profile/faculty_profiles.dart';

// ignore: must_be_immutable
class AddFaculty extends StatefulWidget {
  int idx;

  AddFaculty({Key? key, required this.idx}) : super(key: key);

  @override
  State<AddFaculty> createState() => _AddFacultyState();
}

class _AddFacultyState extends State<AddFaculty> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(lable: Text(facultyDetails, style: headingStyle())),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: subject[widget.idx].isEmpty
                  ? Container()
                  : ListView.builder(
                      scrollDirection: Axis.vertical,
                      itemCount: subject[widget.idx]['subList'].length,
                      itemBuilder: (context, index) => Dismissible(
                        key: Key(subject[widget.idx]['subList'][index]['name']),
                        direction: DismissDirection.endToStart,
                        background: Container(
                            color: red,
                            alignment: Alignment.centerRight,
                            child: Text('Delete', style: commonStyle())),
                        onDismissed: (direction) {
                          subject[widget.idx]['subList'].removeAt(index);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Delete....'),
                            ),
                          );
                          setState(() {});
                        },
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => FacultyName(
                                  fData: subject[widget.idx]['subList'],
                                  index: index,
                                ),
                              ),
                            );
                          },
                          child: Card(
                            elevation: 3,
                            shape: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20)),
                            child: Container(
                              height: Screens.height(context) * 0.072,
                              alignment: Alignment.centerLeft,
                              decoration: BoxDecoration(
                                  color: yellow50,
                                  borderRadius: BorderRadius.circular(20)),
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                subject[widget.idx]['subList'][index]['name'],
                                style: commonStyle(),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
