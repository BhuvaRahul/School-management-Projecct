
class Event {
  final String title;
  Event({required this.title});

  @override
   String toString() => title;

}
