import 'package:global_knowledge_school/common_package.dart';

class FestivalImages extends StatefulWidget {
  const FestivalImages({Key? key}) : super(key: key);

  @override
  State<FestivalImages> createState() => _FestivalImagesState();
}

class _FestivalImagesState extends State<FestivalImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: commonAppbar(
              lable: Text(
            festivalImages,
            style: headingStyle(),
          )),
          floatingActionButton: FloatingActionButton(
            onPressed: () {},
            child: Icon(icAdd),
          ),
          body: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Column(
              children: [
                Expanded(
                  child: GridView.count(
                      crossAxisCount: 1,
                      childAspectRatio: 6.2,
                      children: List.generate(
                        festivals.length,
                        (index) => GestureDetector(
                          onTap: () {
                            if (index == 0) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const DiwaliImages(),
                                  ));
                            }
                            if (index == 1) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const HoliImages(),
                                  ));
                            }
                            if (index == 2) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const UtrayanImages(),
                                  ));
                            }
                            if (index == 3) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const RakshabandhanImages(),
                                  ));
                            }
                            if (index == 4) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const JanmstamiImages(),
                                  ));
                            }
                            if (index == 5) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const IndependecDayImages(),
                                  ));
                            }
                            if (index == 6) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const GaneshChaturthiImages(),
                                  ));
                            }
                            if (index == 7) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const NavaratriImages(),
                                  ));
                            }
                            if (index == 8) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const ChristmasImages(),
                                  ));
                            }
                            if (index == 9) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const RepublicDayImages(),
                                  ));
                            }
                          },
                          child: Card(
                            elevation: 3,
                            shape: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30)),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: yellow50,
                                  borderRadius: BorderRadius.circular(30)),
                              child: Center(
                                child: Text(
                                  festivals[index],
                                ),
                              ),
                            ),
                          ),
                        ),
                      )),
                )
              ],
            ),
          )),
    );
  }
}

class DiwaliImages extends StatefulWidget {
  const DiwaliImages({Key? key}) : super(key: key);

  @override
  State<DiwaliImages> createState() => _DiwaliImagesState();
}

class _DiwaliImagesState extends State<DiwaliImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
          lable: Text(
            diwaliImages,
            style: headingStyle(),
          ),
        ),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              diwali.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            diwali[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class HoliImages extends StatefulWidget {
  const HoliImages({Key? key}) : super(key: key);

  @override
  State<HoliImages> createState() => _HoliImagesState();
}

class _HoliImagesState extends State<HoliImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          holiImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              holi.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            holi[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class UtrayanImages extends StatefulWidget {
  const UtrayanImages({Key? key}) : super(key: key);

  @override
  State<UtrayanImages> createState() => _UtrayanImagesState();
}

class _UtrayanImagesState extends State<UtrayanImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          utrayanImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              utrayan.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            utrayan[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class RakshabandhanImages extends StatefulWidget {
  const RakshabandhanImages({Key? key}) : super(key: key);

  @override
  State<RakshabandhanImages> createState() => _RakshabandhanImagesState();
}

class _RakshabandhanImagesState extends State<RakshabandhanImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          rakshabandhanImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              rakshabandhan.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            rakshabandhan[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class JanmstamiImages extends StatefulWidget {
  const JanmstamiImages({Key? key}) : super(key: key);

  @override
  State<JanmstamiImages> createState() => _JanmstamiImagesState();
}

class _JanmstamiImagesState extends State<JanmstamiImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          janmstamiImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              janmstami.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            janmstami[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class IndependecDayImages extends StatefulWidget {
  const IndependecDayImages({Key? key}) : super(key: key);

  @override
  State<IndependecDayImages> createState() => _IndependecDayImagesState();
}

class _IndependecDayImagesState extends State<IndependecDayImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          independenceImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              independenceDay.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            independenceDay[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class GaneshChaturthiImages extends StatefulWidget {
  const GaneshChaturthiImages({Key? key}) : super(key: key);

  @override
  State<GaneshChaturthiImages> createState() => _GaneshChaturthiImagesState();
}

class _GaneshChaturthiImagesState extends State<GaneshChaturthiImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          ganeshchturthiImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              ganeshChaturthi.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            ganeshChaturthi[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class NavaratriImages extends StatefulWidget {
  const NavaratriImages({Key? key}) : super(key: key);

  @override
  State<NavaratriImages> createState() => _NavaratriImagesState();
}

class _NavaratriImagesState extends State<NavaratriImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          navratriImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              navratri.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            navratri[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class ChristmasImages extends StatefulWidget {
  const ChristmasImages({Key? key}) : super(key: key);

  @override
  State<ChristmasImages> createState() => _ChristmasImagesState();
}

class _ChristmasImagesState extends State<ChristmasImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          christmasImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              christmas.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            christmas[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

class RepublicDayImages extends StatefulWidget {
  const RepublicDayImages({Key? key}) : super(key: key);

  @override
  State<RepublicDayImages> createState() => _RepublicDayImagesState();
}

class _RepublicDayImagesState extends State<RepublicDayImages> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: commonAppbar(
            lable: Text(
          republicImages,
          style: headingStyle(),
        )),
        body: GridView.count(
          crossAxisCount: 1,
          mainAxisSpacing: 12,
          children: List.generate(
              republic.length,
              (index) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                            republic[index],
                          ),
                          fit: BoxFit.fill),
                    ),
                  )),
        ),
      ),
    );
  }
}

List festivals = [
  'Diwali',
  'Holi',
  'Utrayan',
  'RakshaBandhan',
  'Janmstami',
  'Independence Day',
  'Ganesh Chaturthi',
  'Navratri',
  'Christmas',
  'Republic Day',
];
List diwali = [
  'assets/images/diwali2.jpg',
  'assets/images/diwali5.png',
];
List holi = [
  'assets/images/holi1.png',
  'assets/images/holi2.png',
];
List utrayan = [
  'assets/images/makar1.png',
  'assets/images/makar2.png',
];

List rakshabandhan = [
  'assets/images/rak1.png',
  'assets/images/rak2.png',
];

List janmstami = [
  'assets/images/jan1.png',
  'assets/images/jan2.png',
];

List independenceDay = [
  'assets/images/inde1.png',
  'assets/images/inde2.png',
];

List ganeshChaturthi = [
  'assets/images/ganesh1.png',
  'assets/images/ganesh2.png',
];

List navratri = [
  'assets/images/navratri1.png',
  'assets/images/navratri2.png',
];

List christmas = [
  'assets/images/christams1.png',
  'assets/images/christams2.png',
];

List republic = [
  'assets/images/rep1.png',
  'assets/images/rep2.png',
];
