import 'package:global_knowledge_school/common_package.dart';

class TimeTablePage extends StatefulWidget {
  const TimeTablePage({Key? key}) : super(key: key);

  @override
  _TimeTablePageState createState() => _TimeTablePageState();
}

const List<String> tabNames = <String>[
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday'
];

class _TimeTablePageState extends State<TimeTablePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  Color color = red;
  bool teacher = true;
  bool edit = false;

  @override
  void initState() {
    super.initState();
    _tabController =
        TabController(vsync: this, initialIndex: 0, length: tabNames.length);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppbar(
        lable: Text(
          'Time Table',
          style: headingStyle(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: List.generate(
          tabNames.length,
          (index) => teacher
              ? TeachersTimeTable(
                  color: color,
                )
              : StudentsTimeTable(
                  color: color,
                ),
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            children: <Widget>[
              Expanded(
                child: InkWell(
                  onTap: () {
                    teacher = true;
                    setState(() {});
                  },
                  child: Container(
                    height: 45,
                    decoration: BoxDecoration(
                        color: teacher ? color : white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Center(
                      child: Text(
                        'Teachers',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: !teacher ? black : white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: InkWell(
                  onTap: () {
                    teacher = false;
                    setState(() {});
                  },
                  child: Container(
                    height: 45,
                    decoration: BoxDecoration(
                        color: !teacher ? color : white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Center(
                      child: Text(
                        'Students',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: teacher ? black : white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          AnimatedCrossFade(
            firstChild: Material(
              color: grey,
              child: TabBar(
                indicatorColor: white,
                controller: _tabController,
                isScrollable: true,
                tabs: List.generate(tabNames.length, (index) {
                  return Card(
                    elevation: 10,
                    shape: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Container(
                      height: 40,
                      width: Screens.width(context) * 0.3,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(
                        child: Text(
                          tabNames[index].toUpperCase(),
                          style: const TextStyle(
                              fontSize: 18,
                              color: black,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
            secondChild: Container(),
            crossFadeState: CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 300),
          ),
        ],
      ),
    );
  }
}
