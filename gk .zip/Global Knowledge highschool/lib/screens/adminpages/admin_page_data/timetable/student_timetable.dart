import 'package:global_knowledge_school/common_package.dart';

class StudentsTimeTable extends StatefulWidget {
  final Color color;
  final bool edit;

  const StudentsTimeTable({Key? key, required this.color, this.edit = false})
      : super(key: key);

  @override
  _StudentsTimeTableState createState() => _StudentsTimeTableState();
}

class _StudentsTimeTableState extends State<StudentsTimeTable> {
  bool edit = false;
  TextEditingController txtSubjectNameController = TextEditingController();
  TextEditingController txtTeacherNameController = TextEditingController();
  TextEditingController txtLecStartController = TextEditingController();
  TextEditingController txtLecEndController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    edit = widget.edit;
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Card(
          elevation: 5,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              TextField(
                expands: false,
                controller: txtSubjectNameController,
                enableInteractiveSelection: true,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Lecture',
                  labelStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              TextField(
                expands: false,
                controller: txtTeacherNameController,
                enableInteractiveSelection: true,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Teacher name',
                  labelStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      expands: false,
                      controller: txtLecStartController,
                      enableInteractiveSelection: true,
                      keyboardType: TextInputType.datetime,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                        labelText: 'Start time',
                        labelStyle: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    "  To  ",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      expands: false,
                      controller: txtLecEndController,
                      enableInteractiveSelection: true,
                      keyboardType: TextInputType.datetime,
                      textInputAction: TextInputAction.done,
                      decoration: const InputDecoration(
                        labelText: 'End time',
                        labelStyle: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              verticalSpace(
                vertical: Screens.height(context) * 0.02,
              ),
              commonButtons(
                  lable: const Text('Save'),
                  onPress: () {
                    studentTimeTable.add({
                      'lecture': txtSubjectNameController.text,
                      'teacherName': txtSubjectNameController.text,
                      'startTime': txtSubjectNameController.text,
                      'endTime': txtSubjectNameController.text,
                    });
                  })
            ],
          ),
        ),
      ),
    );
  }
}

List<Map> studentTimeTable = [];
