import 'package:global_knowledge_school/common_package.dart';

class TeachersTimeTable extends StatefulWidget {
  final Color color;
  final bool edit;

  const TeachersTimeTable({Key? key, required this.color, this.edit = false})
      : super(key: key);

  @override
  _TeachersTimeTableState createState() => _TeachersTimeTableState();
}

class _TeachersTimeTableState extends State<TeachersTimeTable> {
  bool edit = false;

  @override
  Widget build(BuildContext context) {
    edit = widget.edit;
    return SafeArea(
      child: Scaffold(
        backgroundColor: white,
        body: ListView.builder(
          itemCount: 1,
          itemBuilder: (context, index) => buildListTile(index),
        ),
      ),
    );
  }

  Card buildListTile(int index) {
    return Card(
      elevation: 5,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          lectureTextField(),
          standardTextField(),
          Row(
            children: <Widget>[
              starttimeTExtField(),
              const Text(
                "  To  ",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              endtimeTextField()
            ],
          ),
          verticalSpace(vertical: 5),
          commonButtons(
              lable: const Text('Save'),
              onPress: () {
                facultyTimeTable.add({
                  'lecture': txtLectureController.text,
                  'standard': txtStandardController.text,
                  'startTime': txtStartTimeController.text,
                  'endTime': txtEndTimeController.text,
                });
              })
        ],
      ),
    );
  }
}
