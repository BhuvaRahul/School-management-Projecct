import 'package:flutter/material.dart';

const Color black = Colors.black;
const Color white = Colors.white;
const Color blue = Colors.blue;
Color green300 = Colors.green.shade300;
const Color grey = Colors.grey;
const Color red = Colors.red;
const Color pink = Colors.pink;
const Color black12 = Colors.black12;
const Color yellow = Colors.yellow;
Color yellow50 = Colors.yellow.shade50;
