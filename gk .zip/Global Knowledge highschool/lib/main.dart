import 'package:flutter/material.dart';
import 'package:global_knowledge_school/screens/splashscreen/splash_screen.dart';

void main() {
  runApp(
     const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplahScreen(),
    ),
  );
}
